/* -----------------------------------------------------------------------------
 * Programmer(s): David J. Gardner @ LLNL
 * -----------------------------------------------------------------------------
 * SUNDIALS Copyright Start
 * Copyright (c) 2025-2026, Lawrence Livermore National Security,
 * University of Maryland Baltimore County, and the SUNDIALS contributors.
 * Copyright (c) 2013-2025, Lawrence Livermore National Security
 * and Southern Methodist University.
 * Copyright (c) 2002-2013, Lawrence Livermore National Security.
 * All rights reserved.
 *
 * See the top-level LICENSE and NOTICE files for details.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * SUNDIALS Copyright End
 * -----------------------------------------------------------------------------
 * Implementation header file with forward declarations of ARKODE types.
 * ---------------------------------------------------------------------------*/

#ifndef _ARKODE_TYPES_IMPL_H
#define _ARKODE_TYPES_IMPL_H

typedef struct ARKodeMemRec* ARKodeMem;
typedef struct ARKodeRelaxMemRec* ARKodeRelaxMem;

#endif
