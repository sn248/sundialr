..
   -----------------------------------------------------------------------------
   SUNDIALS Copyright Start
   Copyright (c) 2002-2024, Lawrence Livermore National Security
   and Southern Methodist University.
   All rights reserved.

   See the top-level LICENSE and NOTICE files for details.

   SPDX-License-Identifier: BSD-3-Clause
   SUNDIALS Copyright End
   -----------------------------------------------------------------------------

.. _SUNDIALS_DEV:

sundialsdev Python Library
==========================

This is a Python library of utilities SUNDIALS developer may find useful.
Right now it consists of the following modules:

- ``logs``: this module has functions for parsing logs produced by `SUNLogger`.

