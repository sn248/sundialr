**Bug Fixes**

Fixed a `bug <https://github.com/LLNL/sundials/pull/523>`_ in v7.1.0 with the SYCL N_Vector ``N_VSpace`` function. 
